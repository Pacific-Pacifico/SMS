package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertInTable 
{
	public InsertInTable(String table_name,String ...values)
	{
		Connection con=new DbConnect().getDbConnection();
		if(con==null)
		{
			System.out.println("connection is null");
		}		
		else
		{
			String query="insert into "+table_name+ " values (?,?)";
			try 
			{
				PreparedStatement st=con.prepareStatement(query);
				st.setInt(1, Integer.parseInt(values[0]));
				st.setString(2, values[1]);
				int count=st.executeUpdate();

				System.out.println(count + " row(s) affected");

				st.close();
			}
			catch (NumberFormatException e) 
			{
				e.printStackTrace();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		try
		{
			con.close();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		System.out.println("insertion in table successful");
	}

	public static void main(String[] args) 
	{
		InsertInTable iit=new InsertInTable("section1", "2","shyam");
	}
}
