package db;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTables 
{
	public CreateTables(String ...tableNames)
	{
		Connection con=new DbConnect().getDbConnection();
		if(con==null)
		{
			System.out.println("connection is null");
		}		
		else
		{
			for(String table_name:tableNames)
			{
				String query="create table "+ table_name + "(id int NOT NULL,"
						+ "name varchar(20) NOT NULL)";
				try 
				{
					Statement st=con.createStatement();
					st.executeUpdate(query);
					st.close();
				}
				catch (SQLException e) 
				{
					e.printStackTrace();
				}	
			}
			try
			{
				con.close();
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			System.out.println("tables successfully created");
		}
	}
	
	public static void main(String[] args) 
	{
//		for classes
		CreateTables cct=new CreateTables("class1","class2");
		
//		for sections
		CreateTables sct=new CreateTables("section1","section2");
	}
}
