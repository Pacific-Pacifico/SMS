package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Login extends JFrame implements ActionListener
{	
	Container c;
	JButton admin,guest;
	
	public Login()
	{
		c=this.getContentPane();
		c.setLayout(null);
		
		admin=new JButton("Admin Login");
		guest=new JButton("Guest Login");
		
		windowSetter();
		boundSetter();
		componentsAdder();
		eventSetter();
	}
	
	void boundSetter()
	{
		admin.setBounds(25,200 ,200 ,100 );
		guest.setBounds(250,200 , 200,100 );
	}
	
	void windowSetter()
	{
		setTitle("SMS");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500,200,500,500);
		setResizable(false);
	}
	
	void componentsAdder()
	{
		c.add(admin);
		c.add(guest);
	}
	
	void eventSetter()
	{
		admin.addActionListener(this);
		guest.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==admin)
		{
			new PassWindow();
			dispose();
		}
		else if(e.getSource()==guest)
		{
			new ViewWindow();
			dispose();
		}
	}
	
	public static void main(String[] args) 
	{
		Login l=new Login();
	}
	

}
