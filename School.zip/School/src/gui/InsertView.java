package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class InsertView extends JFrame implements ActionListener
{	
	Container c;
	JButton insert,view;
	
	public InsertView()
	{
		c=this.getContentPane();
		c.setLayout(null);
		
		insert=new JButton("Insert record");
		view=new JButton("View record");
		
		windowSetter();
		boundSetter();
		componentsAdder();
		eventSetter();
	}
	
	void boundSetter()
	{
		insert.setBounds(25,200 ,200 ,100 );
		view.setBounds(250,200 , 200,100 );
	}
	
	void windowSetter()
	{
		setTitle("SMS");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500,200,500,500);
		setResizable(false);
	}
	
	void componentsAdder()
	{
		c.add(insert);
		c.add(view);
	}
	
	void eventSetter()
	{
		insert.addActionListener(this);
		view.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==insert)
		{
			new InsertWindow();
			dispose();
		}
		else if(e.getSource()==view)
		{
			new ViewWindow();
			dispose();
		}
	}
	
	public static void main(String[] args) 
	{
		InsertView iv=new InsertView();
	}
	

}
