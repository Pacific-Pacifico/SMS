package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

class VFrame extends JFrame implements ActionListener,ItemListener
{	
	Container c;
	JButton view;
	Vector<String> classes;
	Vector<String> sections;
	
	JComboBox cbc,cbs;
	
	public VFrame()
	{
		c=this.getContentPane();
		c.setLayout(null);
		
		classes=new Vector<String>();
		for(int i=1;i<=10;i++)
		{
			classes.add("Class "+i);
		}
		for(int i=0;i<5;i++)
		{
			System.out.println(classes.get(i));
		}
		
		sections=new Vector<String>();
		for(int i=65;i<70;i++)
		{
			sections.add("Section "+(char)i);
		}
		for(int i=0;i<5;i++)
		{
			System.out.println(sections.get(i));
		}
		
		cbc=new JComboBox<String>(classes);
		cbs=new JComboBox<String>(sections);
		
		cbc.setSelectedIndex(-1);
		cbs.setSelectedIndex(-1);
		
		cbs.setEnabled(false);
		
		view=new JButton("View");
		
		view.setEnabled(false);
		
		windowSetter();
		boundSetter();
		componentsAdder();
		eventSetter();
	}
	
	void boundSetter()
	{
		cbc.setBounds(25, 50, 150, 50);
		cbs.setBounds(200, 50, 150, 50);
		
		view.setBounds(450,50 ,150 ,50 );
	}
	
	void windowSetter()
	{
		setTitle("SMS");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		setBounds(400,100,850,700);
		setBounds(400,400,650,200);
		setResizable(false);
	}
	
	void componentsAdder()
	{
		c.add(cbc);
		c.add(cbs);
		
		c.add(view);
	}
	
	void eventSetter()
	{
		cbc.addItemListener(this);
		cbs.addItemListener(this);
		
		view.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==view)
		{
			new InfoTable();
			dispose();
		}
	}
	
	public void itemStateChanged(ItemEvent e)
	{
		if(e.getSource()==cbc)
		{
			cbs.setEnabled(true);
		}
		else if(e.getSource()==cbs)
		{
			view.setEnabled(true);
		}
	}
}

public class ViewWindow
{
	public ViewWindow()
	{
		VFrame mf=new VFrame();
	}
	
	public static void main(String[] args) 
	{
		VFrame mf=new VFrame();
	}
}
