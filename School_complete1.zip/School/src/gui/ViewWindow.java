package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

class VFrame extends JFrame implements ActionListener,ItemListener
{	
	Container c;
	JButton view;
	Vector<String> classes;
	Vector<String> sections;
	
	JComboBox cbc,cbs;
	
	public VFrame()
	{
		c=this.getContentPane();
		c.setLayout(null);
		
		classes=new Vector<String>();
		for(int i=1;i<=10;i++)
		{
			classes.add("Class "+i);
		}
//		for(int i=0;i<10;i++)
//		{
//			System.out.println(classes.get(i));
//		}
		
		sections=new Vector<String>();
		for(int i=65;i<70;i++)
		{
			sections.add("Section "+(char)i);
		}
//		for(int i=0;i<5;i++)
//		{
//			System.out.println(sections.get(i));
//		}
		
		cbc=new JComboBox<String>(classes);
		cbs=new JComboBox<String>(sections);
		
		cbc.setSelectedIndex(-1);
		cbs.setSelectedIndex(-1);
		
		cbs.setEnabled(false);
		
		view=new JButton("View");
		
		view.setEnabled(false);
		
		windowSetter();
		boundSetter();
		componentsAdder();
		eventSetter();
	}
	
	void boundSetter()
	{
		cbc.setBounds(25, 50, 150, 50);
		cbs.setBounds(200, 50, 150, 50);
		
		view.setBounds(450,50 ,150 ,50 );
	}
	
	void windowSetter()
	{
		setTitle("SMS");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		setBounds(400,100,850,700);
		setBounds(400,400,650,200);
		setResizable(false);
	}
	
	void componentsAdder()
	{
		c.add(cbc);
		c.add(cbs);
		
		c.add(view);
	}
	
	void eventSetter()
	{
		cbc.addItemListener(this);
		cbs.addItemListener(this);
		
		view.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==view)
		{
//			System.out.println("class selected:"+(cbc.getSelectedIndex()+1));
//			System.out.println("section selected:"+(cbs.getSelectedIndex()+1));
			
			StringBuilder tableName=new StringBuilder("section");
			int i=cbc.getSelectedIndex();
			int j=cbs.getSelectedIndex();
			
			if(i==0)
			{
				tableName.append("1");
			}
			else if(i==1)
			{
				tableName.append("2");
			}
			else if(i==2)
			{
				tableName.append("3");
			}
			else if(i==3)
			{
				tableName.append("4");
			}
			else if(i==4)
			{
				tableName.append("5");
			}
			else if(i==5)
			{
				tableName.append("6");
			}
			else if(i==6)
			{
				tableName.append("7");
			}
			else if(i==7)
			{
				tableName.append("8");
			}
			else if(i==8)
			{
				tableName.append("9");
			}
			else if(i==9)
			{
				tableName.append("10");
			}
			
			
			if(j==0)
			{
				tableName.append("a");
			}
			else if(j==1)
			{
				tableName.append("b");
			}
			else if(j==2)
			{
				tableName.append("c");
			}
			else if(j==3)
			{
				tableName.append("d");
			}
			else if(j==4)
			{
				tableName.append("e");
			}

			System.out.println(tableName);
			new InfoTable(new String(tableName));
		}
	}
	
	public void itemStateChanged(ItemEvent e)
	{
		if(e.getSource()==cbc)
		{
			cbs.setEnabled(true);
		}
		else if(e.getSource()==cbs)
		{
			view.setEnabled(true);
		}
	}
}

public class ViewWindow
{
	public ViewWindow()
	{
		VFrame mf=new VFrame();
	}
	
	public static void main(String[] args) 
	{
		VFrame mf=new VFrame();
	}
}
