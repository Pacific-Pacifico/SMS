package gui;

import javax.swing.*;

import db.InsertInTable;

import java.awt.*;
import java.awt.event.*;

public class Input extends JFrame implements ActionListener
{
	Container c;
	JLabel l_id,l_name;
	JTextField id,name;
	JButton ok,cancel;
	String table_name;

	public Input(String tableName)
	{
		c=this.getContentPane();
		c.setLayout(null);

		table_name=tableName;
		
		l_id=new JLabel("Enter ID:");
		l_name=new JLabel("Enter Name:");

		id=new JTextField();
		name=new JTextField();

		ok=new JButton("Ok");
		cancel=new JButton("Cancel");

		windowSetter();
		boundSetter();
		componentsAdder();
		eventSetter();
	}

	void boundSetter()
	{
		l_id.setBounds(10, 150,200 ,25 );
		l_name.setBounds(10, 200,200 ,25 );

		id.setBounds(250, 150,200 ,25 );
		name.setBounds(250, 200,200 ,25 );

		ok.setBounds(225, 400, 100,50 );
		cancel.setBounds(350, 400,100 , 50);
	}

	void windowSetter()
	{
		setTitle("SMS");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500,200,500,500);
		setResizable(false);
	}

	void componentsAdder()
	{
		c.add(l_id);
		c.add(l_name);

		c.add(id);
		c.add(name);

		c.add(ok);
		c.add(cancel);
	}

	void eventSetter()
	{
		this.addWindowListener(new WindowAdapter()
		{
			public void windowOpened(WindowEvent e)
			{
				id.requestFocus();
			}

			public void windowActivated(WindowEvent e)
			{
				id.requestFocus();
			}
		});
		ok.addActionListener(this);
		cancel.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==ok)
		{
			new db.InsertInTable(table_name, id.getText(), name.getText());
			JOptionPane.showMessageDialog(this, "Insertion Successful");
			dispose();
			
		}
		else if(e.getSource()==cancel)
		{
			dispose();
		}
	}

	public static void main(String[] args) 
	{
		Input ip=new Input("section1a");
	}
}

