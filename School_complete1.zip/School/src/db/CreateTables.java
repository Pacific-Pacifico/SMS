package db;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTables 
{
	public CreateTables(String type,String ...tableNames)
	{
		Connection con=new DbConnect().getDbConnection();
		if(con==null)
		{
			System.out.println("connection is null");
		}		
		else
		{
			String query=null;
			for(String table_name:tableNames)
			{
				if(type.equals("class"))
				{
					query="create table "+ table_name + "(section_id varchar(20) NOT NULL,"
							+ "Primary key(section_id))";
				}
				else if(type.equals("section"))
				{
					query="create table "+ table_name + "(student_id int NOT NULL,"
							+ "name varchar(20) NOT NULL,Primary key(student_id))";
				}
				try 
				{
					Statement st=con.createStatement();
					st.executeUpdate(query);
					st.close();
				}
				catch (SQLException e) 
				{
					e.printStackTrace();
				}	
			}
			try
			{
				con.close();
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			System.out.println("tables successfully created");
		}
	}

	public static void main(String[] args) 
	{
		String[] classes;
		String[][] sections;
		classes=new String[10];
		sections=new String[10][5];


		for(int i=0;i<10;i++)
		{
			classes[i]="class"+(i+1);
		}

		for(int i=0;i<10;i++)
		{
			for(int j=0,k=65;j<5 && k<70;j++,k++)
			{
				sections[i][j]="section"+(i+1)+(char)k;
			}
		}

		//		for classes
		//		CreateTables cct=new CreateTables("class","class1","class2");
		CreateTables cct=new CreateTables("class",classes);

		//		for sections
		//		CreateTables sct=new CreateTables("section","section1","section2");
		for(int i=0;i<10;i++)
		{
			CreateTables sct=new CreateTables("section",sections[i]);
		}
	}
}
