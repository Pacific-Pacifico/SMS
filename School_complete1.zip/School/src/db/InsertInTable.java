package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

public class InsertInTable 
{
	public InsertInTable(String table_name,String ...values)
	{
		Connection con=new DbConnect().getDbConnection();
		if(con==null)
		{
			System.out.println("connection is null");
		}		
		else
		{
			String query="insert into "+table_name+ " values (?,?)";
			try 
			{
				PreparedStatement st=con.prepareStatement(query);
				st.setInt(1, Integer.parseInt(values[0]));
				st.setString(2, values[1]);
				int count=st.executeUpdate();

				System.out.println(count + " row(s) affected");

				st.close();
			}
			catch (NumberFormatException e) 
			{
				e.printStackTrace();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		try
		{
			con.close();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		System.out.println("insertion in table successful");
	}

	public static void main(String[] args) 
	{
		//		InsertInTable iit=new InsertInTable("section1a", "2","shyam");

		int[] s_ids=new int[5];
		String[] samples= {"Ram","Shyam","Mohan","Sohan","Preeti"};
		String[] s_names=new String[5];
		String[][] sections=new String[10][5];

		for(int i=0;i<10;i++)
		{
			for(int j=0,k=65;j<5 && k<70;j++,k++)
			{
				sections[i][j]="section"+(i+1)+(char)k;
			}
		}

		for(int o=0;o<10;o++)
		{
			for(int i=0;i<5;i++)
			{
				Random r=new Random();
				long fraction = (long)(100 * r.nextDouble());
				s_ids[i]= (int)(fraction + 1);
				//			System.out.print(s_ids[i]+"  ");

				s_names[i]=samples[r.nextInt(samples.length)];
				//			System.out.println(s_names[i]);		
				InsertInTable iit=new InsertInTable(sections[o][i],String.valueOf(s_ids[i]),s_names[i]);
			}
			System.out.println();
		}
	}
}
