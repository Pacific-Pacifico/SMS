package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

class IFrame extends JFrame implements ActionListener,ItemListener
{	
	Container c;
	JButton insert;
	Vector<String> classes;
	Vector<String> sections;
	
	JComboBox cbc,cbs;
	
	public IFrame()
	{
		c=this.getContentPane();
		c.setLayout(null);
		
		classes=new Vector<String>();
		for(int i=1;i<=10;i++)
		{
			classes.add("Class "+i);
		}
		for(int i=0;i<5;i++)
		{
			System.out.println(classes.get(i));
		}
		
		sections=new Vector<String>();
		for(int i=65;i<70;i++)
		{
			sections.add("Section "+(char)i);
		}
		for(int i=0;i<5;i++)
		{
			System.out.println(sections.get(i));
		}
		
		cbc=new JComboBox<String>(classes);
		cbs=new JComboBox<String>(sections);
		
		cbc.setSelectedIndex(-1);
		cbs.setSelectedIndex(-1);
		
		cbs.setEnabled(false);
		
		insert=new JButton("Insert");
		
		insert.setEnabled(false);
		
		windowSetter();
		boundSetter();
		componentsAdder();
		eventSetter();
	}
	
	void boundSetter()
	{
		cbc.setBounds(25, 50, 150, 50);
		cbs.setBounds(200, 50, 150, 50);
		
		insert.setBounds(450,50 ,150 ,50 );
	}
	
	void windowSetter()
	{
		setTitle("SMS");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		setBounds(400,100,850,700);
		setBounds(400,400,650,200);
		setResizable(false);
	}
	
	void componentsAdder()
	{
		c.add(cbc);
		c.add(cbs);
		
		c.add(insert);
	}
	
	void eventSetter()
	{
		cbc.addItemListener(this);
		cbs.addItemListener(this);
		
		insert.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==insert)
		{
//			new InfoTable();
			dispose();
		}
	}
	
	public void itemStateChanged(ItemEvent e)
	{
		if(e.getSource()==cbc)
		{
			cbs.setEnabled(true);
		}
		else if(e.getSource()==cbs)
		{
			insert.setEnabled(true);
		}
	}
}

public class InsertWindow
{
	public InsertWindow()
	{
		IFrame mf=new IFrame();
	}
	
	public static void main(String[] args) 
	{
		IFrame mf=new IFrame();
	}
}
