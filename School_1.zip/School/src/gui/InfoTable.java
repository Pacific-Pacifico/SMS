package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InfoTable extends JFrame implements ActionListener
{	
	JTable jt;
	JScrollPane jsp;
	DefaultTableModel tm;
	
	public InfoTable(String tableName)
	{		
//		String[] columnNames= {"Id","Name"};
//		String[][] data= {
//				{"1","Abc"},
//				{"2","xyz"}
//		};
		
		tm=new DefaultTableModel();
//		jt=new JTable(data,columnNames);
		jt=new JTable(tm);
		
		tm.addColumn("id");
		tm.addColumn("name");
		
//		tm.addRow(new Object[] {"1","shyam"});
//		ResultSet rs=new db.QueryFromTable().getResult("section1a");
		ResultSet rs=new db.QueryFromTable().getResult(tableName);
		try 
		{
			while(rs.next())
			{
//				System.out.println(rs.getInt(1)+" "+rs.getString(2));
				tm.addRow(new Object[] {rs.getInt(1),rs.getString(2)});
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
//		tm.addRow(new Object[] {"1","shyam"});
		
//		tm=(DefaultTableModel)jt.getModel();
//		tm.addRow(new Object[] {"ram","shyam"});;
		
		jt.setBounds(30, 40, 200, 300);
		jsp=new JScrollPane(jt);
		
		windowSetter();
		boundSetter();
		componentsAdder();
		eventSetter();
	}
	
	void boundSetter()
	{
		jt.setBounds(30, 40, 200, 300);
	}
	
	void windowSetter()
	{
		setTitle("SMS");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500,200,500,500);
//		setSize(500,200);
		setResizable(false);
	}
	
	void componentsAdder()
	{
		add(jsp);
	}
	
	void eventSetter()
	{
		
	}
	
	public void actionPerformed(ActionEvent e)
	{
//		if(e.getSource()==admin)
//		{
//			new PassWindow();
//			dispose();
//		}
//		else if(e.getSource()==guest)
//		{
//			new ViewWindow();
//			dispose();
//		}
	}
	
	public static void main(String[] args) 
	{
		InfoTable it=new InfoTable("section1a");
	}
}
