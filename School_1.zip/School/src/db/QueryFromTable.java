package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.net.ssl.SSLException;

public class QueryFromTable 
{
	ResultSet rs=null;
	static Connection con;
	public ResultSet getResult(String table_name)
	{
		con=new DbConnect().getDbConnection();
		if(con==null)
		{
			System.out.println("connection is null");
		}		
		else
		{
			String query="select * from "+table_name;
			
			try 
			{
				Statement st=con.createStatement();
				rs=st.executeQuery(query);
				
//				while(rs.next())
//				{
//					System.out.println(rs.getInt(1)+" "+rs.getString(2));
//				}
//				st.close();
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
//		try
//		{
//			con.close();
//		}
//		catch (SQLException e) 
//		{
//			e.printStackTrace();
//		}
//	
		System.out.println("query from table successful");
		return rs;
	}
	
	public static void main(String[] args) 
	{
		QueryFromTable iit=new QueryFromTable();
		ResultSet rs=iit.getResult("section1");
		try {
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+" "+rs.getString(2));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try
		{
			con.close();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
}
